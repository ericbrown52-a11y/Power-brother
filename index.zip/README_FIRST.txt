POWER BROTHER V7 — FRESH DOWNLOAD

Controls:
- Left/right D-pad to move
- Tap anywhere on the game screen to blast
- Tilt also works if motion permission is allowed
- Top-right circular arrow recalibrates tilt
- Pause button included

Modes:
- Fisher Mode: no real fail state
- Power Up Mode: 3 lives, hearts, and bonus lives

Changes:
- Hover removed
- Enhanced tap-to-blast
- Weather enemies replaced with monsters and aliens
- Better graphics and backgrounds


V8 FIXES:
- Tilt no longer uses 0 as the starting neutral value.
- Tilt auto-calibrates from the phone position at the start of each run.
- Added a dead zone so the hero does not drift right on its own.
- Left and right arrow controls are now split on opposite sides of the screen.


V9 BALANCE + TILT FIXES:
- Tilt direction inverted to match natural leaning.
- Power Up mode now spawns fewer extra lives.
- Power Up mode now has more enemies and hazards.
- Progression is more active and challenging.


V10 CHANGES:
- Blaster is now explicitly directional based on the exact screen point you tap.
- Enemy set is monster-only: slime, bat monster, eyeball, goblin, and chomper.
- Removed alien and saucer enemies.
- Enemies now spawn higher above platforms so they do not hide inside platform art.
- Monster visuals have stronger outlines/shadows for readability.


V11 TILT TOGGLE:
- Added Tilt Steering ON/OFF toggle to the main menu.
- ON requests and uses iPhone motion controls.
- OFF disables tilt completely and uses split left/right buttons only.
- Recalibrate works when tilt is ON.


V12 TILT DIRECTION FIX:
- Tilt direction reversed to match natural leaning.
- Menu toggle remains in place.
- Buttons and tap-to-shoot unchanged.


V13 TILT CALIBRATION FIX:
- Tilt no longer locks into the direction the phone was leaning at startup.
- At the start of each run, the game pauses tilt input for about 0.9 seconds and averages the phone position as neutral.
- While calibrating, hold the phone in the normal play position.
- Recalibrate button now repeats that same hold-level calibration.
